//Name:Walid Zein
//NetID:WAZ170030
//Project5


#include <stdio.h>
#include "GridNode.h"

// constructor
GridNode::GridNode()
{
    up = NULL;
    down = NULL;
    left = NULL;
    right = NULL;
}

// overloaded constructor, sets the position of node
GridNode::GridNode(int r, int c)
{
    row = r;
    column = c;
    up = NULL;
    down = NULL;
    left = NULL;
    right = NULL;
}

// Set value to character
void GridNode::SetChar(bool bold)
{
    if (bold)
    {
        // put bold mark
        character = '#';
    }
    else
    {
        // check if empty, to not write over bold mark
        if (character == ' ')
        {
            // write tiny
            character = '*';
        }
    }
}
