//Name:Walid Zein
//NetID:WAZ170030
//Project5



#include <stdio.h>
#include <iostream>
#include <fstream>
#include "BaseNode.h"
#include "Grid.h"
#include "GridNode.h"


// Constructor
Grid::Grid()
{
    head = NULL;
    CreateGrid();
}

// Overloaded constructor with already created head
Grid::Grid(GridNode* head)
{
    this->head = head;
    current = head;
    pen = false;
    bold = false;
}

// Destructor
Grid::~Grid()
{
    GridNode * gn1;
    GridNode * gn2 = head;
    GridNode * tmp;

    // Visit all nodes and delete them
    while (gn2 != NULL)
    {
        gn1 = gn2;
        gn2 = gn2->down;
        while (gn1 != NULL)
        {
            tmp = gn1;
            gn1 = gn1->right;
            delete tmp;
        }
    }
}

// Creates the nodes and link them to 50x50 matrix
void Grid::CreateGrid()
{
    GridNode * gnr;
    GridNode * gnd;
    GridNode * tmp;

    // If no head, create it
    if (head == NULL)
    {
        head = new GridNode(1, 1);
    }

    //Create 50 rows of nodes
    gnd = head;
    for (int j = 1; j <= 50; j++)
    {
        gnr = gnd;
        //Create a new node and link it to the bottom of previous
        if (j != 50)
        {
            gnd = new GridNode(j + 1, 1);
            gnr->down = gnd;
            gnd->up = gnr;
        }

        // Create a row of 50 nodes
        for (int i = 2; i <= 50; i++)
        {
            tmp = new GridNode(j, i);
            gnr->right = tmp;
            tmp->left = gnr;
            gnr = tmp;
        }
    }

    // Link rows into a grid
    gnr = head;
    // Start from first row
    // Select two neighbour rows, navigate trough top row and link elements up/down with second row
    while (gnr->down != NULL)
    {
        gnd = gnr->down;
        tmp = gnd;
        // Loop trough row
        while (gnr != NULL)
        {
            gnr->down = gnd;
            gnd->up = gnr;
            gnr = gnr->right;
            gnd = gnd->right;
        }
        gnr = tmp;
    }
    current = head; // set current position to head
    pen = false;
    bold = false;
}

// Moves up by 1 in grid, if pen then set the character
bool Grid::MoveUp()
{
    bool isOK = (current->up != NULL);
    if (isOK)
    {
        current = current->up;
        if (pen)
        {
            current->SetChar(bold);
        }
    }
    return isOK;
}

// Moves down by 1 in grid, if pen then set the character
bool Grid::MoveDown()
{
    bool isOK = (current->down != NULL);
    if (isOK)
    {
        current = current->down;
        if (pen)
        {
            current->SetChar(bold);
        }
    }
    return isOK;
}

// Moves left by 1 in grid, if pen then set the character
bool Grid::MoveLeft()
{
    bool isOK = (current->left != NULL);
    if (isOK)
    {
        current = current->left;
        if (pen)
        {
            current->SetChar(bold);
        }
    }
    return isOK;
}

// Moves right by 1 in grid, if pen then set the character
bool Grid::MoveRight()
{
    bool isOK = (current->right != NULL);
    if (isOK)
    {
        current = current->right;
        if (pen)
        {
            current->SetChar(bold);
        }
    }
    return isOK;
}

// Extracts commands to command and parameters
void Grid::ExtractCommand(char* com, char* command, char* direction, int* num)
{
    int i = 0;
    // Set command
    *command = com[i];
    // If command is 3
    if (*command == '3')
    {
        i++;
        // Skip whitespace and comma
        while ((com[i] == ',') || (com[i] == ' '))
        {
            i++;
        }
        // Set direction, next character
        *direction = com[i];
        i++;
        // Skip whitespace and comma
        while ((com[i] == ',') || (com[i] == ' '))
        {
            i++;
        }
        // Set number from characters
        *num = 0;
        while ((com[i] >= '0') && (com[i] <= '9'))
        {
            *num = *num * 10 + com[i] - 0x30;
            i++;
        }
    }
}

// Executes command from file
void Grid::ExecuteCommand(char* command)
{
    char com, direction;
    int num;
    int i;
    // Extract the command, get parameters
    ExtractCommand(command, &com, &direction, &num);
    switch (com)
    {
        case '1': // pen up
            pen = false;
            break;
        case '2': // pen down
            pen = true;
            break;
        case '3': // move pen and draw line if pen is down
            i = 0;
            switch (direction)
            {
                case 'N': // North
                    if ((current->GetRow() - num) > 0)
                    {
                        while (i < num)
                        {
                            MoveUp();
                            i++;
                        }
                    }
                    break;
                case 'S': // South
                    if ((current->GetRow() + num) <= 50)
                    {
                        while (i < num)
                        {
                            MoveDown();
                            i++;
                        }
                    }
                    break;
                case 'E': // East
                    if ((current->GetColumn() + num) <= 50)
                    {
                        while (i < num)
                        {
                            MoveRight();
                            i++;
                        }
                    }
                    break;
                case 'W': // West
                    if ((current->GetColumn() - num) > 0)
                    {
                        while (i < num)
                        {
                            MoveLeft();
                            i++;
                        }
                    }
                    break;
            }
            break;
        case '4':            // Print output list to console
            std::cout << *this;
            break;
        case 'B': // bold (#)
            bold = true;
            break;
        case 'b': // not bold (*)
            bold = false;
            break;
    }
}

// overloaded ostream operator
std::ostream &operator <<(std::ostream& o, Grid& grid)
{
    GridNode * gn1;
    GridNode * gn2 = grid.head;
    // Loop all rows
    while (gn2 != NULL)
    {
        gn1 = gn2;
        // Loop row and put characters in ostream
        while (gn1 != NULL)
        {
            o << gn1->GetChar();
            gn1 = gn1->right;
        }
        o << std::endl;
        gn2 = gn2->down;
    }
    o << std::endl << std::endl;
    return o;
}



