//Name:Walid Zein
//NetID:WAZ170030
//Project5


#include "BaseNode.h"

// Constructor
BaseNode::BaseNode()
{
    row = 1;
    column = 1;
    character = ' ';
}

// Overloaded constructor
BaseNode::BaseNode(int r, int c)
{
    row = r;
    column = c;
    character = ' ';
}

// Method to get value of protected character
char BaseNode::GetChar()
{
    return character;
}

// Method to get value of protected row
int BaseNode::GetRow()
{
    return row;
}

// Method to get value of protected column
int BaseNode::GetColumn()
{
    return column;
}
