//Name:Walid Zein
//NetID:WAZ170030
//Project5



#ifndef BASENODE_H_INCLUDED
#define BASENODE_H_INCLUDED

class BaseNode
{
protected:
    int row;
    int column;
    char character;
public:
    BaseNode();
    BaseNode(int r, int c);
    virtual void SetChar(bool bold) = 0; // pure virtual method
    char GetChar(); // returns char, used on printing
    int GetRow(); // returns row of the element
    int GetColumn(); // returns column of he element
};


#endif // BASENODE_H_INCLUDED
