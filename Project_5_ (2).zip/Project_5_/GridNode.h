//Name:Walid Zein
//NetID:WAZ170030
//Project5


#ifndef GRIDNODE_H_INCLUDED
#define GRIDNODE_H_INCLUDED

#include "BaseNode.h"

// Inherited from BaseNode abstract class
class GridNode:BaseNode
{
public:
    // pointers to neighbours
    GridNode * up;
    GridNode * down;
    GridNode * left;
    GridNode * right;
    GridNode(); // constructor
    GridNode(int r, int c); // overloaded constructor
    void SetChar(bool bold); // set the value of the character
    // Using parent class methods
    using BaseNode::GetRow;
    using BaseNode::GetColumn;
    using BaseNode::GetChar;
};


#endif // GRIDNODE_H_INCLUDED
