//Name:Walid Zein
//NetID:WAZ170030
//Project5

#include <cstdlib>
#include <iostream>
#include <fstream>
#include "GridNode.h"
#include "Grid.h"

using namespace std;

int main()
{
    Grid grid;
    char * command = new char[255];
    ofstream ofile;
    ifstream ifile;
    // Open file for reading
    ifile.open("commands5.txt");
    if (ifile.is_open())
    {
        // Read file line by line
        while (!ifile.eof())
        {
            ifile.getline(command, 255);
            // Execute every line from file
            grid.ExecuteCommand(command);
        }
        ifile.close();
    }
    else
    {
        cout << "Cant open commands.txt file." << endl;
    }
    // overloaded ostream operator is used
    std::cout << grid;
    ofile.open("paint.txt");
    if (ofile.is_open())
    {
        // overloaded ofstream operator is used
        ofile << grid;
        ofile.close();
    }
    else
    {
        std::cout << "Cant create paint.txt file" << std::endl;
    }
    delete command;
    return 0;
}

