//Name:Walid Zein
//NetID:WAZ170030
//Project5


#ifndef GRID_H_INCLUDED
#define GRID_H_INCLUDED

#include <iostream>
#include <fstream>
#include "GridNode.h"

class Grid
{
private:
    GridNode * head; // pointer to upper left corner
    GridNode * current; // pointer to node where the pen is
    bool pen;
    bool bold;
    // Extract command and parameters from a line in file
    void ExtractCommand(char * com, char * command, char * direction, int * num);
public:
    Grid(); // constructor
    Grid(GridNode * head); // overloaded constructor
    ~Grid(); // destructor
    void CreateGrid(); // creates and links nodes in a grid

    // Navigation
    bool MoveUp();
    bool MoveDown();
    bool MoveLeft();
    bool MoveRight();

    void ExecuteCommand(char * command); // Execute the command

    // Friend class to overload << for ostream
    friend std::ostream &operator<<(std::ostream &o, Grid &grid);
};



#endif // GRID_H_INCLUDED
